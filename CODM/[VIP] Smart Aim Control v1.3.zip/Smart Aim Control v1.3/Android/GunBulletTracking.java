{
  name: ["com.tencent.tmgp.pubgmhd"]
   <DOCTYPE Java>
   <Java>
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   while true
do
do
                "bullet tracking_FOV=360°×360=head"
"bullet tracking_FOV=360°×360°"
            "Bullet tracking intensity=MAX
            "bullet tracking=MAX
            "Gun Bullet Tracking=MAX
     "Bullet trajectory tracking = MAX
     "Bullet trajectory tracking = head
          "Bullet tracking hit rate=MAX
"Gun firing, bullets automatically tracking the head=MAX
     "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
     "Firearms firing, bullets tracking character's head=MAX
     "Gun bullets automatically hit the head=MAX
     "Firearms firing, bullets tracking the head=MAX
     "Firearm tracking area=MAX
     "Bullet tracking area=MAX
     "Gun and bullet tracking=MAX
     "Gun and bullet tracking area=head
     "Character moves firearms, fires bullets, and tracks the head=MAX
     "Character head tracking=MAX
     "Bullet tracking on the character's head=MAX
     "Character moving firearms firing bullets tracking head=MAX
     "Automatic tracking of characters' heads by firearms and bullets=MAX
     "Character moves firearms, fires bullets, automatically tracks hits to the head=MAX
     "Bullet trajectory tracking hits character moving head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms fire to track and hit the character's head=MAX
     "Bullet automatic tracking moving character moving head=MAX
     "Bullet automatic tracking of moving character's head=MAX
     "Character Movement Bullet Tracking=MAX
     "Character Movement Bullet Tracking=head
     "Bullet locked character head tracking=MAX
     "Bullet locks character's head=MAX
     "Fire to lock the character's head=MAX
     "Bullet target locking and tracking head=MAX
     "Target lock tracking character head=MAX
     "Bullet trajectory line dispersion reduces tracking head=MAX
          "Bullet impact area hit tracking head=MAX
     "Bullet head tracking head area=MAX
     "Bullets gather and hit the tracking head=MAX
     "Bullet area tracking character range=MAX
     "Bullet hit the head=MAX
     "Gun bullets hit the head=MAX
     "Guns and bullets tracking character heads=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
     "Bullet Rifling Tracking Character's Head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms firing, bullets moving, characters moving, tracking heads=MAX
       "Bullet tracking head range=MAX
       "Bullet tracking hit head area=MAX
     "Bullet tracking area hit range=MAX
     "Bullet tracking area hits head range=MAX
     "Enlargethecharacter'shead=MAX
         "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
     "Firearms firing, bullets tracking character's head=MAX
     "Gun bullets automatically hit the head=MAX
     "Firearms firing, bullets tracking the head=MAX
     "The character moves bullets to track the enemy's head=MAX
     "Firearms fire to track character heads=MAX
     "Gun shooting range tracking character's head=MAX
     "Firearm tracking area=MAX
     "Bullet tracking area=MAX
     "Gun and bullet tracking=MAX
     "Automatic tracking head for firearms and bullets =MAX
     "Firearms fire to track and hit the character's head=MAX
     "Bullet automatic tracking moving character moving head=MAX
     "Bullet automatic tracking of moving character's head=MAX
     "Bullet hit tracking character's head=MAX
            "Gun Bullet Tracking=MAX
     "Automatic tracking of character bullet trajectory = MAX
"Gun firing, bullets automatically tracking the head=MAX

                     }:"execute"
             <Java>